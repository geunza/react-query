import axios from "axios";
import queryString from "query-string";
import { useEffect, useRef, useState } from "react";
import { useQuery } from "react-query";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { styled } from "styled-components";
// 하단 interface들은 내가 지금 쓰는 api기준으로 따왔으니까, 이건 본인 api형태에 맞게 가공을 요함.
interface PrdItem {
  be_price: number;
  img: string;
  price: number;
  prod_name: string;
  product_no: number;
  sale: number;
  site_name: string;
  site_type: string;
}
interface QueryResult {
  result: PrdItem[];
  total_element: number;
  total_page: number;
}
// 정확하게 뭐가 들어올지 모르지만, 분명히 string : string이라면 아래와 같이 작성 가능.
// 대신 나중에 타입에 대해서 까다로워질 수 있음.
// 하지만 쿼리스트링으로 들어오는 값은 모두 string이기 때문에 아래처럼 배짱부리기 가능(상황봐서)
interface FetchType {
  [key: string]: string;
}

// 내가 쓰는 api에서 받는 사이트 네임. 원래는 이것도 별도 api호출로 가져오는데, 이건 react-query랑 관계없다 생각들어서 깡코딩으로 넣음.
const siteType = ["IN", "ET", "AB", "NA", "OL", "TO", "CL"];

const List: React.FC<{}> = () => {
  // 이 컴포넌트는 props가 없는 상태.
  const location = useLocation(); // 현재의 쿼리스트링을 가져 오기 위한 훅
  const navigate = useNavigate(); // Link가 아닌 어떠한 이벤트로 라우터를 구동시켜서 링크이동을 시켜주기 위한 훅
  const [query, setQuery] = useState(queryString.parse(location.search)); // 바뀌는 쿼리값을 담아줄 state. react-query에서 key로 사용 됨.
  const [currentPage, setCurrentPage] = useState(
    queryString.parse(location.search).page ?? 0
  ); // 필요할 것 같아서 넣었는데, 페이지네이션을 대충만들게 되면서 의미 없어짐. 하지만 setCurrentPage를 넣는 부분은 꽤나 유용할 듯.

  useEffect(() => {
    // ~~가 변할때마다 실행된다.
    const parsed = queryString.parse(location.search); // 1
    parsed.page ? setCurrentPage(parsed.page) : setCurrentPage(0); // 2
    setQuery(parsed); // 3
    // 1. 아래에서 반복될 내용. 하지만 그만큼 중요한 로직
    // 1-1. location.search :  현재의 쿼리스트링을 가져온다.( ?page=1&site_type=NA 와 같은 string 형태)
    // 1-2. queryString.parse(쿼리스트링) : 쿼리스트링을 오브젝트 형태로 변환 ( {page:1, site_type:"NA"} )
    // 2. 해당 오브젝트 중 page값을 판별 후, 있으면 해당 값으로, 없으면 0으로 현재 page state를 setState해준다
    // 3. react-query가 구동되도록 query값을 바꿔준다. 이게 trigger가 되서 react-query가 실행 됨.
  }, [location.search]); // 뭐가 변할때마다 실행되는 지는 여기 배열 안에 있다.

  // 데이터를 가져오는 함수. 아마 인자를 넣어야 할텐데 이거 타입잡는게 개빡셈. 짜증남.
  const fetchProduct = ({
    page, // 쿼리스트링을 통해 인자로 넣어줄 page
    query, // 쿼리스트링을 통해 인자로 넣어줄 query
    site_type, // 쿼리스트링을 통해 인자로 넣어줄 site_type
  }: FetchType): Promise<QueryResult> => {
    // axios 자체를 리턴하는거긴 한데,
    // axios에서 결과값으로 받아온 result, total_page, total_element를 리턴하는 것.
    // 착각하면 안됨
    return axios // axios자체를 리턴 하는 것 같지만!
      .get("http://heycosmetics.kr:446/api/v1/product/list", {
        params: {
          size: 10, // 우리쪽 api에서 한번에 몇개의 데이터를 보내줄 지 정하는 파라미터. 그냥 10으로 고정값 넣어뒀음
          page, // 쿼리스트링을 통해 받아올 page
          query, // 쿼리스트링을 통해 받아올 query
          site_type, // 쿼리스트링을 통해 받아올 site_type
        },
      })
      .then((res) => {
        // 데이터 응답을 받으면?
        const {
          data: { result, total_page, total_element },
        } = res;
        return {
          result, // 얘네들을 리턴함.
          total_page, // 얘네들을 리턴함.
          total_element, // 얘네들을 리턴함.
          // 즉 axios를 리턴하는데, axios함수가 얘네들을 리턴하니까 최종적으로는 얘네들이 리턴되는것.
        };
      });
  };

  const {
    data: { result, total_page, total_element } = {}, //비동기기 때문에 데이터가 undeinfed일 수 있으니 ={}로 에러 방지.
    isLoading, // 넣어주라던데? 로딩처리랑 에러처리는 안했음.
    isError, // 넣어주라던데? 로딩처리랑 에러처리는 안했음.
  } = useQuery<QueryResult>(
    [query /* 얘가 변할때마다 변함(key값 이라고 하던데..) */],
    () => fetchProduct(query as FetchType),
    // 이 부분을 실행함. 나는 query가 변하면 query값을 인자로 넘겨서 위에 fetchProduct에서 사용. 쿼리스트링이니 순서가 어찌될지 몰라 오브젝트 형태로 named parameter로 넘김
    // 나는 인자를 넘겨야 하기 때문에 ()=>{} 형태로 썻지만, 인자를 안넘긴다면(함수 자체에서 query를 끌고온다든지 등..) 그냥 fetchProduct로 사용 가능. 괄호 없이~
    {
      refetchOnWindowFocus: false, // 뭐랬더라 다른 탭 갔다가 다시 오면 재실행 할건지 여부?
      retry: 0, // 실패시 재시도 여부?
      onSuccess: (result) => {
        // 성공시 뭐할래?
        console.log("result", result);
      },
      onError: (err) => {
        // 실패시에는 뭐할건데?
        console.log("err", err);
      },
    }
  );

  const submitQuery = (e: React.FormEvent<HTMLFormElement>) => {
    // input으로 받는 데이터는 Link이동을 못시키기에 별도의 함수를 만들어줄 필요가 있음.
    e.preventDefault(); // 일단 리로드 방지부터 하고
    if (queryRef.current) {
      // 타입스크립트 특 : 있는지 없는지 체크 해줘야함.
      if (queryRef.current.value) {
        // 타입스크립트 특아님. 있을때와 없을때의 최종 로직이 다르기 때문.
        // 인풋에 글자가 있을때
        const currentQueryObj = queryString.parse(location.search); // 쿼리스트링 오브젝트화
        const newQueryObj = {
          ...currentQueryObj,
          page: 1, // 검색어가 변했을때는 페이지가 1이 되야함. 안그러면 검색했을때 실제 데이터는 3페이지까지 밖에 없는데 쿼리상으로는 7페이지에 존재하는 등의 경우가 생김.
          query: queryRef.current.value, // query라는 이름의 쿼리스트링을 넣기 위한 초석.
        };

        const toSearch = queryString.stringify(newQueryObj); // 오브젝트의 쿼리스트링화
        navigate({
          // 이 페이지 안에서 쿼리스트링만 바꿔줄거니까
          pathname: location.pathname, // 쿼리스트링이 아닌 부분은 그대로(path)
          search: toSearch, // 쿼리스트링은 위에서 만든 데이터로
        }); // 슝~
      } else {
        // 인풋에 글자가 없을때
        const currentQueryObj = queryString.parse(location.search); //동일함. if문 위로 빼도 상관 없는데, 이정도는 최적화에 큰 도움은 안될 듯하기도 하고, 괜히 헷갈릴까봐 아래에 넣어둠.
        delete currentQueryObj.query; // 안없애줘도 어차피 ?page=1&query=&site_type=NA 이런식으로 들어가기때문에 상관 없긴 한데, 빼주는게 깔끔함.
        const newQueryObj = {
          ...currentQueryObj,
        }; // 그대로 넣기보다는 이럴때는 구조분해를 이용해 새로운 오브젝트로 만드는걸 추천(내 취향)
        const toSearch = queryString.stringify(newQueryObj); // 동일
        navigate({
          // 동일
          pathname: location.pathname, // 동일
          search: toSearch, // 동일
        }); // 슝~
      }
    }
  };
  const queryRef = useRef<HTMLInputElement>(null); // input값을 받기 위한 ref. 대신 타입검증이 귀찮아지는 단점이 있음. + validation을 최종에만 돌릴 수 있어서 중간중간 뭘 체크해야하면 state로 하셈
  return (
    <>
      {result?.map(
        (
          v,
          idx // 87번 라인에서 받아온 result
        ) => (
          <StyledP key={idx}>
            <span className="product_no">{v.product_no}</span>
            {/* 그냥 넣음 */}
            <span className="site_type">[{v.site_type}]</span>{" "}
            {/* site_type값에 따라  변하는거 보라고.. */}
            <span className="prod_name">{v.prod_name}</span>{" "}
            {/* query값에 따라 변하는거 보라고.. */}
          </StyledP>
        )
      )}
      <div id="pagination">
        {Array(10) // 10까지만 보이게 하고, total_page가 그것보다 낮으면 안보이게 하려는 꼼수. 임시 페이지네이션이니까 이 방법은 무시하길~
          .fill("_")
          .slice(0, Math.min(10, total_page ?? 10))
          .map((v, idx) => {
            const currentQueryObj = queryString.parse(location.search); // 1, 2
            const newQueryObj = { ...currentQueryObj, page: idx }; // 3
            const toSearch = queryString.stringify(newQueryObj); // 4
            // 1. location.search를 콘솔에 찍어보면 ?page=1&site_type=ET 이런식으로 string값이 나옴.
            // 2. queryString이라는 라이브러리를 이용해서 오브젝트 형태로 변환 {page : "1", site_type : "ET"}. 쿼리스트링은 항상 string type이라는걸 명심!
            // 3. 새로운 객체를 만들면서 뒤에 page값을 추가. 이렇게 하는 이유는 현재 page값이 있다면 덮어씌우고, 없으면 추가하는 가장 간단한 방법이기 때문.
            // 4. 2번에서 object형태로 변환시켰던 쿼리스트링을 모두 가공했으니 다시 문자열 형태로 변환.
            // etc : 쿼리스트링 라이브러리 사용시
            // - queryString.parse(현재 쿼리스트링) : 현재 쿼리스트링을 오브젝트 형태로
            // - queryString.stringify(대상 obj) : 대상 obj를 쿼리스트링 형태로.(앞에 "?" 도 붙여줌)
            return (
              <StyledLink
                to={{
                  pathname: location.pathname,
                  search: toSearch,
                }}
                // Link를 사용해서 링크이동을 하는데, pathname은 현재의 경로 그대로, search는 위에 1~4번을 이용해 가공한 최종값인 toSearch를 적용
                key={idx} //대충 넣어놓은 key값
              >
                {idx}
              </StyledLink>
            );
          })}
      </div>
      <div id="site">
        {siteType.map((v, idx) => {
          // 상단 pagination과 동일한 로직. 다른점은 page가 아닌 site_type을 덮어씌운다는 점.
          const currentQueryObj = queryString.parse(location.search);
          const newQueryObj = { ...currentQueryObj, page: 1, site_type: v }; // page값을 1로 되돌리는걸 잊지 않기!
          const toSearch = queryString.stringify(newQueryObj);
          return (
            <StyledLink
              key={idx}
              to={{
                pathname: location.pathname,
                search: toSearch,
              }}
            >
              {v}
            </StyledLink>
          );
        })}
      </div>
      <form onSubmit={submitQuery}>
        {/* form과 form의 onSubmit을 쓴 이유는 엔터를 쳤을때 검색이 되기 하기 위함. */}
        <input type="text" ref={queryRef} />
        {/* state선언하기 귀찮아서 ref썻음. state로 해도 무관 */}
        <input type="submit" value="SUBMIT" />
      </form>
    </>
  );
};

export default List;

// 하단은 그냥 스타일
const StyledP = styled.p`
  font-size: 16px;
  .product_no {
  }
  .site_name {
  }
  .prod_name {
  }
`;
const StyledLink = styled(Link)`
  padding: 5px 10px;
  border: 1px solid #000;
  cursor: pointer;
  display: inline-block;
`;
